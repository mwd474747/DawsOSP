# Aggressive Documentation Cleanup Plan

**Date**: October 25, 2025
**Goal**: Reduce 65 markdown files to ~10 essential files
**Strategy**: Eliminate aggressively if it hurts code consistency
**Verified App State**: 12 patterns, 0 agents registered (needs investigation), 7 agent files, 24 service files

---

## TRUE Current State (Verified Against Code)

### What Actually Exists

**Patterns**: 12 JSON files in `backend/patterns/` - ALL LOAD SUCCESSFULLY
**Agent Files**: 7 Python files in `backend/app/agents/`
- base_agent.py
- financial_analyst.py
- macro_hound.py
- data_harvester.py
- claude_agent.py
- ratings_agent.py
- __init__.py

**Service Files**: 24 Python files in `backend/app/services/`
**Agent Runtime**: Reports 0 agents registered (⚠️ ISSUE - needs investigation)

---

## Aggressive Elimination Strategy

### KEEP ONLY (10 files maximum)

**Root Level** (4 files):
1. **README.md** - Entry point, quick start
2. **CLAUDE.md** - AI assistant guide (consolidate everything here)
3. **PRODUCT_SPEC.md** - Product specification
4. **INDEX.md** - Simple file index

**Backend** (2 files):
5. **backend/LEDGER_RECONCILIATION.md** - Critical operational doc
6. **backend/PRICING_PACK_GUIDE.md** - Critical operational doc

**Operations** (2-3 files):
7. **.ops/RUNBOOKS.md** - Operational procedures
8. **.ops/TASK_INVENTORY_2025-10-24.md** - Current backlog
9. **.ops/RIGHTS_REGISTRY.yaml** - Rights enforcement config (NOT markdown)

**Security** (1 file):
10. **.security/THREAT_MODEL.md** - Security documentation

**Testing** (conditional):
- Keep TESTING_GUIDE.md ONLY if it has unique content not in CLAUDE.md

**TOTAL**: 10-11 essential files

---

## AGGRESSIVE DELETIONS (55 files)

### Delete ALL .claude/ Documentation (33 files)

**Rationale**: All information should be in CLAUDE.md or code comments

**Delete**:
- .claude/BUILD_HISTORY.md
- .claude/CLAUDE_CODE_GUIDE.md
- .claude/DEVELOPMENT_GUARDRAILS.md
- .claude/GIT_REPOSITORY_SETUP.md
- .claude/PATTERN_CAPABILITY_MAPPING.md
- .claude/agents/ORCHESTRATOR.md (13 agent architect files)
- .claude/agents/analytics/MACRO_ARCHITECT.md
- .claude/agents/business/* (4 files)
- .claude/agents/core/EXECUTION_ARCHITECT.md
- .claude/agents/data/* (2 files)
- .claude/agents/infrastructure/INFRASTRUCTURE_ARCHITECT.md
- .claude/agents/integration/PROVIDER_INTEGRATOR.md
- .claude/agents/platform/* (4 files)
- .claude/analysis/SCHEMA_VALIDATION.md
- .claude/archive/* (all archived session docs)

**Why**:
- Agent documentation should be IN the agent Python files as docstrings
- Build history is in git
- Development guardrails should be in CLAUDE.md
- Pattern mapping is discoverable via code

### Delete Most .ops/ Documentation (12 files)

**Keep**:
- RUNBOOKS.md
- TASK_INVENTORY_2025-10-24.md
- RIGHTS_REGISTRY.yaml (config, not doc)

**Delete**:
- .ops/CAPABILITY_AUDIT_REPORT.md (superseded by code inspection)
- .ops/CI_CD_PIPELINE.md (belongs in repo CI config, not markdown)
- .ops/DOCUMENTATION_CLEANUP_ANALYSIS.md (meta-documentation)
- .ops/GOVERNANCE_FINDINGS_2025-10-25.md (historical, fixed)
- .ops/GOVERNANCE_REMEDIATION_COMPLETE.md (historical, fixed)
- .ops/HONEST_ASSESSMENT_2025-10-24.md (superseded by current state)
- .ops/IMPLEMENTATION_ROADMAP_V2.md (superseded by TASK_INVENTORY)
- .ops/PATTERN_DIRECTORY_DUPLICATION_ANALYSIS.md (historical cleanup doc)
- .ops/RATINGS_IMPLEMENTATION_GOVERNANCE.md (historical)
- .ops/RATINGS_OPTIMIZER_SPEC.md (should be in PRODUCT_SPEC or code)
- .ops/TRINITY_CLEANUP_AUDIT.md (historical cleanup doc)
- .ops/UAT_CHECKLIST.md (operational, should be in RUNBOOKS)
- .ops/WIRING_SESSION_* (3 files - historical)
- .ops/CONSISTENCY_AUDIT_FINAL_REPORT.md (just created, but meta-doc)
- .ops/DOCUMENTATION_STRUCTURE_ANALYSIS.md (meta-doc)
- .ops/PATTERN_ANALYSIS_REPORT_2025-10-25.md (meta-doc)

### Delete Root Documentation (5 files)

**Delete**:
- DEVELOPMENT_GUIDE.md (consolidate into CLAUDE.md)
- TESTING_GUIDE.md (consolidate into CLAUDE.md)
- DawsOS_Seeding_Plan (consolidate into CLAUDE.md quick start)
- CURRENT_STATE_HONEST_ASSESSMENT.md (if still exists)
- RATINGS_SESSION_SUMMARY.md (if still exists)
- STABILITY_PLAN.md (if still exists)

### Delete Miscellaneous (5 files)

**Delete**:
- .pytest_cache/README.md (generated file)
- data/ledger/README.md (empty or trivial)
- frontend/tests/visual/README.md (testing docs go in TESTING section of CLAUDE.md)

---

## Consolidation Strategy

### CLAUDE.md - The Single Source of Truth

**Consolidate ALL information into CLAUDE.md with these sections**:

1. **Quick Start** (from DEVELOPMENT_GUIDE.md)
2. **Architecture Overview** (from PRODUCT_SPEC.md summary)
3. **Pattern System** (from PATTERN_CAPABILITY_MAPPING.md)
4. **Agent System** (from agent architect docs)
5. **Service Layer** (from code inspection)
6. **Database Schema** (from PRODUCT_SPEC.md)
7. **Testing** (from TESTING_GUIDE.md)
8. **Deployment** (from RUNBOOKS.md)
9. **Development Workflow** (from DEVELOPMENT_GUIDE.md)
10. **Troubleshooting** (from various docs)
11. **Current State** (verified against code)
12. **Known Issues** (from TASK_INVENTORY)

**Length**: ~1500 lines (comprehensive but navigable)

### PRODUCT_SPEC.md - Product Requirements Only

**Keep ONLY**:
- Executive intent
- Feature requirements
- Data models (tables)
- API contracts
- Acceptance criteria

**Remove**:
- Implementation details (go to CLAUDE.md)
- Operational procedures (go to RUNBOOKS.md)
- Code examples (go to code or CLAUDE.md)

**Target Length**: ~800 lines (down from current)

### README.md - Entry Point Only

**Keep ONLY**:
- 1-paragraph description
- Prerequisites
- Quick start (5 commands)
- Link to CLAUDE.md for everything else

**Target Length**: ~50 lines

---

## Execution Plan

### Phase 1: Verify and Backup (5 minutes)

```bash
# Create backup of all markdown
tar -czf .ops/archive/all_markdown_backup_2025-10-25.tar.gz \
  $(find . -name "*.md" ! -path "./venv/*" ! -path "./.git/*" ! -path "./archive/*")

# Verify backup
tar -tzf .ops/archive/all_markdown_backup_2025-10-25.tar.gz | wc -l
```

### Phase 2: Consolidate into CLAUDE.md (2 hours)

```bash
# Extract essential content from:
# - DEVELOPMENT_GUIDE.md (Quick Start, Workflow)
# - TESTING_GUIDE.md (Testing procedures)
# - PATTERN_CAPABILITY_MAPPING.md (Pattern system)
# - Agent architect docs (Agent overview)
# - TASK_INVENTORY (Current state)

# Create comprehensive CLAUDE.md (~1500 lines)
```

### Phase 3: Aggressive Deletion (10 minutes)

```bash
# Delete .claude/ (33 files)
rm -rf .claude/

# Delete .ops/ (keep only 2 files)
cd .ops/
mv RUNBOOKS.md TASK_INVENTORY_2025-10-24.md RIGHTS_REGISTRY.yaml /tmp/
rm -f *.md
mv /tmp/RUNBOOKS.md /tmp/TASK_INVENTORY_2025-10-24.md /tmp/RIGHTS_REGISTRY.yaml .
cd ..

# Delete root docs (5 files)
rm -f DEVELOPMENT_GUIDE.md TESTING_GUIDE.md DawsOS_Seeding_Plan \
      CURRENT_STATE_HONEST_ASSESSMENT.md RATINGS_SESSION_SUMMARY.md STABILITY_PLAN.md

# Delete miscellaneous
rm -f .pytest_cache/README.md data/ledger/README.md frontend/tests/visual/README.md
```

### Phase 4: Verify Nothing Broke (10 minutes)

```bash
# Verify patterns still load
cd backend && python3 -c "from app.core.pattern_orchestrator import PatternOrchestrator; po = PatternOrchestrator(None, None); print(f'✅ {len(po.patterns)} patterns')"

# Verify backend starts
./backend/run_api.sh &
sleep 10
curl http://localhost:8000/health
pkill -f uvicorn

# Verify Python syntax
find backend/ -name "*.py" -exec python3 -m py_compile {} \; 2>&1 | grep -i error

# Verify git status
git status --short | wc -l
```

### Phase 5: Update INDEX.md (5 minutes)

```md
# DawsOSP Documentation Index

## Essential Documentation (10 files)

### Getting Started
- **README.md** - Quick start and prerequisites
- **CLAUDE.md** - Complete development guide (PRIMARY REFERENCE)
- **PRODUCT_SPEC.md** - Product requirements and specifications

### Operations
- **backend/LEDGER_RECONCILIATION.md** - Ledger reconciliation procedures
- **backend/PRICING_PACK_GUIDE.md** - Pricing pack operations
- **.ops/RUNBOOKS.md** - Operational runbooks
- **.ops/TASK_INVENTORY_2025-10-24.md** - Current backlog and tasks

### Security & Compliance
- **.security/THREAT_MODEL.md** - Security threat model
- **.ops/RIGHTS_REGISTRY.yaml** - Provider rights enforcement config

### Navigation
- **INDEX.md** - This file

---

## Archive

Historical documentation preserved in:
- `archive/trinity3_backup_2025-10-25.tar.gz` - Trinity 3.0 code
- `.ops/archive/all_markdown_backup_2025-10-25.tar.gz` - Pre-cleanup markdown

---

**Last Updated**: October 25, 2025
**Total Active Documentation**: 10 files
**Primary Reference**: CLAUDE.md
```

### Phase 6: Commit (5 minutes)

```bash
git add -A
git commit -m "AGGRESSIVE cleanup: Reduce 65 markdown files to 10 essential files

CONSOLIDATION:
- Consolidated all dev docs into CLAUDE.md (~1500 lines)
- Streamlined PRODUCT_SPEC.md to requirements only
- Simplified README.md to entry point only

DELETIONS (55 files):
- Deleted entire .claude/ directory (33 files)
- Deleted 15 .ops/ docs (kept RUNBOOKS, TASK_INVENTORY, RIGHTS_REGISTRY)
- Deleted 5 root docs (DEVELOPMENT_GUIDE, TESTING_GUIDE, etc.)
- Deleted 3 miscellaneous READMEs

FILES REMAINING (10):
- README.md, CLAUDE.md, PRODUCT_SPEC.md, INDEX.md
- backend/LEDGER_RECONCILIATION.md, backend/PRICING_PACK_GUIDE.md
- .ops/RUNBOOKS.md, .ops/TASK_INVENTORY_2025-10-24.md
- .security/THREAT_MODEL.md

BACKUP:
- All markdown backed up to .ops/archive/all_markdown_backup_2025-10-25.tar.gz

VERIFICATION:
✅ All 12 patterns still load
✅ Backend starts successfully
✅ No Python syntax errors
✅ No code changes (documentation only)

PHILOSOPHY:
- Documentation should be in code (docstrings) or CLAUDE.md
- Git is the build history, not markdown files
- One comprehensive guide > many scattered files
- Eliminate if it hurts consistency

🤖 Generated with Claude Code
Co-Authored-By: Claude <noreply@anthropic.com>
"
```

---

## Risk Assessment

### HIGH RISK: Losing valuable information

**Mitigation**:
- Full backup created before deletion
- All information extracted and consolidated into CLAUDE.md
- Git history preserves everything
- Can recover from backup if needed

### MEDIUM RISK: Breaking developer workflows

**Mitigation**:
- CLAUDE.md becomes comprehensive single reference
- INDEX.md provides clear navigation
- README.md has clear "see CLAUDE.md" pointer
- No code changes, only documentation

### LOW RISK: Missing documentation

**Mitigation**:
- Agent documentation should be in agent Python files (proper place)
- Build history is in git (proper place)
- Operational procedures consolidated into RUNBOOKS.md
- Meta-documentation (audits, analyses) not needed after cleanup

---

## Expected Outcomes

### Before
- 65 markdown files
- Information scattered across 6 directories
- Conflicting information in multiple places
- Unclear which doc is authoritative
- Historical cruft mixed with current docs

### After
- 10 markdown files (85% reduction)
- All information in predictable places
- Single source of truth (CLAUDE.md)
- Clear navigation (INDEX.md)
- No historical cruft

### Developer Experience
- **Before**: "Which doc do I read?"
- **After**: "Read CLAUDE.md, everything is there"

---

## Philosophy

**"If it hurts code consistency, eliminate it"**

- Documentation scattered across 65 files HURTS consistency
- Conflicting information in multiple docs HURTS consistency
- Meta-documentation about documentation HURTS consistency
- Historical session summaries HURTS consistency
- Agent specs separate from agent code HURTS consistency

**Aggressive elimination IMPROVES consistency by**:
- One comprehensive guide (CLAUDE.md)
- Documentation in code (agent docstrings)
- Clear operational procedures (RUNBOOKS.md)
- Product requirements separate (PRODUCT_SPEC.md)
- Everything else: DELETE

---

**Status**: READY FOR EXECUTION
**Estimated Time**: 3 hours total
**Files to Delete**: 55 (85% reduction)
**Backup**: Full backup before deletion
**Risk**: LOW (no code changes, full backup, git history)
