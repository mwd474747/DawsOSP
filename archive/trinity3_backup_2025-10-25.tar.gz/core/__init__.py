"""Core components - Pattern engine, actions, agent runtime"""
