"""Intelligence Layer - Entity extraction, conversation memory, enhanced chat"""
